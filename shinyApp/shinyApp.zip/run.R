rm(list=ls(all=TRUE))

library(shiny)
# setwd("C:/Users/kovalav/Documents/GitHub/ShinyEFA")
# setwd("D:/Users/Will/Documents/GitHub/ShinyEFA")
shiny::runApp('shinyApp')

